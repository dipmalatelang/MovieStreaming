package com.netflix.app.home.ui;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.netflix.app.R;
import com.netflix.app.home.model.MovieData;

/**
 * A simple {@link Fragment} subclass.
 */
public class HomeDetails_Fragment extends Fragment {
    private ImageView MovieThumbnailImg,MovieCoverImg;
    private TextView tv_title,tv_description;
    private FloatingActionButton play_fab;



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_home_details_, container, false);
        play_fab =  view.findViewById(R.id.play_fab);
        tv_title = view.findViewById(R.id.detail_movie_title);
        tv_description = view.findViewById(R.id.detail_movie_desc);
        MovieCoverImg = view.findViewById(R.id.detail_movie_cover);
        MovieThumbnailImg = view.findViewById(R.id.detail_movie_img);

        iniViews();

        return view;
    }
    void iniViews() {

        String movieTitle = getActivity().getIntent().getExtras().getString("title");
        int imageResourceId = getActivity().getIntent().getExtras().getInt("imgURL");
        int imagecover = getActivity().getIntent().getExtras().getInt("imgCover");
        Glide.with(this).load(imageResourceId).into(MovieThumbnailImg);
        MovieThumbnailImg.setImageResource(imageResourceId);
        Glide.with(this).load(imagecover).into(MovieCoverImg);

        tv_title.setText(movieTitle);
        ((AppCompatActivity)getActivity()).getSupportActionBar().setSubtitle(movieTitle);
        // setup animation
        MovieCoverImg.setAnimation(AnimationUtils.loadAnimation(getContext(),R.anim.scale_animation));
        play_fab.setAnimation(AnimationUtils.loadAnimation(getContext(),R.anim.scale_animation));





    }


}
