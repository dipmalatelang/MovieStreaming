package com.netflix.app.main;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.netflix.app.R;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}
